/*no way to check if this works, just create index*/
CREATE INDEX LookUpOrders 
ON Orders(bookID, memberID);